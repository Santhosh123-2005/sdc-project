const loginForm = document.getElementById('loginForm');
const loginSection = document.getElementById('loginSection');
const appContent = document.getElementById('appContent');
const userBanner = document.getElementById('userBanner');
const userGreeting = document.getElementById('userGreeting');
const userRoleText = document.getElementById('userRoleText');
const diagnosisForm = document.getElementById('diagnosisForm');
const imageUpload = document.getElementById('imageUpload');
const imagePreview = document.getElementById('imagePreview');
const resultsSection = document.getElementById('resultsSection');
const presenceValue = document.getElementById('presenceValue');
const categoryValue = document.getElementById('categoryValue');
const subtypeValue = document.getElementById('subtypeValue');
const severityValue = document.getElementById('severityValue');
const shapList = document.getElementById('shapList');
const camPreview = document.getElementById('camPreview');
const reportText = document.getElementById('reportText');
const copyReportButton = document.getElementById('copyReportButton');
const diagnosisStatus = document.getElementById('diagnosisStatus');
const toggleMode = document.getElementById('toggleMode');
const submitButton = document.getElementById('submitButton');
const confirmPasswordRow = document.getElementById('confirmPasswordRow');
const logoutButton = document.getElementById('logoutButton');

let authMode = 'login';
let authToken = null;
const API_BASE = 'http://127.0.0.1:8000/api';

const sampleSHAP = [
  { label: 'BMI', score: '+0.30' },
  { label: 'Menstrual cycle length', score: '+0.18' },
  { label: 'LH/FSH ratio', score: '+0.12' },
  { label: 'Hirsutism score', score: '+0.08' },
  { label: 'Follicle count', score: '+0.07' }
];

function renderImagePreview(file) {
  if (!file) {
    imagePreview.innerHTML = '<span>No image selected</span>';
    return;
  }

  imagePreview.innerHTML = `<span class="selected-file">Selected: ${file.name}</span>`;
  const reader = new FileReader();
  reader.onload = () => {
    imagePreview.innerHTML = `
      <img src="${reader.result}" alt="Ultrasound preview" />
      <span class="selected-file">${file.name}</span>
    `;
  };
  reader.onerror = () => {
    imagePreview.innerHTML = `<span class="upload-error">Could not preview ${file.name}</span>`;
  };
  reader.readAsDataURL(file);
}

imageUpload.addEventListener('change', (event) => {
  const file = event.target.files[0];
  renderImagePreview(file);
});

function renderSHAP() {
  shapList.innerHTML = sampleSHAP
    .map(
      (item) =>
        `<div class="shap-item"><span>${item.label}</span><span class="shap-value">${item.score}</span></div>`
    )
    .join('');
}

function formatReport(data) {
  return `PCOS Diagnostic Report\n\nPatient Age: ${data.age} years\nBMI: ${data.bmi}\nMenstrual Cycle Length: ${data.cycleLength} days\n\nConclusion:\n- Disease Presence: ${data.presence}\n- Category: ${data.category}\n- Subtype: ${data.subtype}\n- Severity: ${data.severity}\n\nInterpretation:\nThe model integrates clinical features with ultrasound imaging using a lightweight multimodal fusion pipeline. SHAP highlights BMI, cycle irregularity, and LH/FSH ratio as top clinical contributors, while Grad-CAM++ identifies the most informative ovarian ultrasound regions.\n\nRecommendation:\nReview the report with a clinician. Further endocrine evaluation and management should be based on the patient’s full clinical presentation and laboratory data.`;
}

function simulateDiagnosis(formData) {
  return new Promise((resolve) => {
    diagnosisStatus.textContent = 'Evaluating';

    setTimeout(() => {
      const result = {
        presence: formData.bmi > 28 || formData.hirsutism > 12 ? 'Positive' : 'Borderline',
        category: 'Hyperandrogenic',
        subtype: 'IR-Related',
        severity: formData.cycleLength > 40 ? 'Moderate' : 'Mild',
        age: formData.age,
        bmi: formData.bmi,
        cycleLength: formData.cycleLength
      };
      resolve(result);
    }, 1300);
  });
}

function updateResults(result) {
  presenceValue.textContent = result.presence;
  categoryValue.textContent = result.category;
  subtypeValue.textContent = result.subtype;
  severityValue.textContent = result.severity;
  reportText.value = formatReport(result);
  camPreview.innerHTML = '<span>Grad-CAM++ overlay simulated for the uploaded image.</span>';
  diagnosisStatus.textContent = 'Completed';
  resultsSection.classList.remove('hidden');
}

function logout() {
  authToken = null;
  loginSection.classList.remove('hidden');
  appContent.classList.add('hidden');
  userBanner.classList.add('hidden');
  resultsSection.classList.add('hidden');
  diagnosisForm.reset();
  renderImagePreview(null);
  loginForm.reset();
  setAuthMode('login');
}

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();

  const userType = document.getElementById('userType').value;
  const username = document.getElementById('username').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;

  if (!userType || !username || !email || !password) {
    alert('Please complete all fields to continue.');
    return;
  }

  if (authMode === 'register') {
    if (password !== confirmPassword) {
      alert('Passwords do not match. Please verify and try again.');
      return;
    }

    try {
      await registerUser({ user_type: userType, username, email, password });
      alert('Registration successful! Please sign in.');
      setAuthMode('login');
    } catch (error) {
      alert(error.message || 'Registration failed.');
    }
    return;
  }

  try {
    const auth = await loginUser({ user_type: userType, username, password });
    authToken = auth.token;
    loginSection.classList.add('hidden');
    appContent.classList.remove('hidden');
    userBanner.classList.remove('hidden');
    userGreeting.textContent = auth.username;
    userRoleText.textContent = auth.user_type;
  } catch (error) {
    alert(error.message || 'Invalid credentials. Please check your username and password or register a new account.');
  }
});

async function registerUser(payload) {
  const response = await fetch(`${API_BASE}/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.detail || 'Registration error');
  }

  return response.json();
}

async function loginUser(payload) {
  const response = await fetch(`${API_BASE}/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.detail || 'Login failed');
  }

  return response.json();
}

function setAuthMode(mode) {
  authMode = mode;
  const heading = loginSection.querySelector('h2');
  const description = loginSection.querySelector('p');
  const emailField = document.getElementById('email');
  const confirmPassword = document.getElementById('confirmPassword');

  if (mode === 'register') {
    heading.textContent = 'Register';
    description.textContent = 'Create a Doctor or Patient account to access the PCOS diagnosis workspace.';
    submitButton.textContent = 'Register';
    toggleMode.textContent = 'Already have an account? Sign In';
    confirmPasswordRow.classList.remove('hidden');
    emailField.required = true;
    confirmPassword.required = true;
  } else {
    heading.textContent = 'Login';
    description.textContent = 'Sign in as a Doctor or Patient to access the PCOS diagnosis workspace.';
    submitButton.textContent = 'Sign In';
    toggleMode.textContent = 'Don\'t have an account? Register';
    confirmPasswordRow.classList.add('hidden');
    emailField.required = true;
    confirmPassword.required = false;
  }
}

toggleMode.addEventListener('click', () => {
  setAuthMode(authMode === 'login' ? 'register' : 'login');
});

logoutButton.addEventListener('click', logout);

setAuthMode('login');

diagnosisForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!authToken) {
    alert('Please login before submitting a diagnosis.');
    return;
  }
  if (!imageUpload.files.length) {
    alert('Please upload an ultrasound image before diagnosing.');
    return;
  }

  const data = new FormData();
  data.append('age', document.getElementById('age').value);
  data.append('bmi', document.getElementById('bmi').value);
  data.append('cycleLength', document.getElementById('cycleLength').value);
  data.append('hirsutism', document.getElementById('hirsutism').value);
  data.append('insulinResistance', document.getElementById('insulinResistance').value);
  data.append('lhFsh', document.getElementById('lhFsh').value);
  data.append('ultrasoundCount', document.getElementById('ultrasoundCount').value);
  data.append('image', imageUpload.files[0]);

  try {
    diagnosisStatus.textContent = 'Evaluating';
    const response = await fetch(`${API_BASE}/diagnose`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
      body: data,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || 'Diagnosis request failed');
    }

    const diagnosis = await response.json();
    renderSHAP();
    updateResults(diagnosis);
    reportText.value = diagnosis.report || reportText.value;
  } catch (error) {
    alert(error.message || 'Failed to submit diagnosis.');
    diagnosisStatus.textContent = 'Error';
  }
});

copyReportButton.addEventListener('click', () => {
  reportText.select();
  document.execCommand('copy');
  copyReportButton.textContent = 'Copied!';
  setTimeout(() => {
    copyReportButton.textContent = 'Copy Report';
  }, 1300);
});

// initial render
resultsSection.classList.add('hidden');
appContent.classList.add('hidden');
